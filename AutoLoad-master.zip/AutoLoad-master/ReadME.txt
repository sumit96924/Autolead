open Your Terminal and Type
./setup.sh
it will install the script for you..
so you can run the script from anywhere in Terminal

Thanks.
