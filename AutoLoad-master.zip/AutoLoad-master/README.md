

                        Welcome to                  
         _         _        _     ___            _  
        / \  _   _| |_ ___ | |   / _ \  __ _  __| |  
       / _ \| | | | __/ _ \| |  | | | |/ _` |/ _` |  
      / ___ \ |_| | || (_) | |__| |_| | (_| | (_| |  
     /_/   \_\__,_|\__\___/|_____\___/ \__,_|\__,_|  
                Automatic Your Proccess               
                       [created by Nafis]   


# AutoLoad
This Script is Automate Your Work 

[*] Things you can do with this Script

1. Make a Payload

:::::This option make a msfvenom reverse_tcp payload for android and windows.
-------------
2. Create a Wordlist 

:::::This option make wordlist based on victim info using cupp!
-------------
3. Create Fake AP

:::::You can create  a Fake Access Point to Hack Facebook Account.Try it!
-------------
4. Deauth Attack

:::::Disconnect users from there wifi network using deauth attack,

:::::You don't need to connect to the wifi or no need to know the password to use deauth Attack
-------------
5. GeoLocate an IP

:::::You can use this option to Find any IP location.
-------------
6. view public ip

:::::as you its mean this option show u your Public IP when u connected to internet.
-------------
7. Crack wpa2 handshake

:::::use aircrack-ng to crack wpa2 handshake file.

8. Capture Handshake

:::::use aircrack-ng to capture wpa2 handshake file.

11. Nmap Scan

:::::Do Multi type of scan through nmap.

::::::::::::::::::::::::::::::::::STAY_UPDATED:::::::::::::::::::::::::::::::::::::

More Things are Coming.........


==================================================================

......Follow Me On.......

YouTube:  https://www.youtube.com/Majorhacker

Website:  http://majorhacke.blogspot.com/

Facebook: http://facebook.com/majorhacke
