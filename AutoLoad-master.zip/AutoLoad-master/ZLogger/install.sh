#!/usr/bin/env bash
sudo apt-get install python-pip
sudo pip install pyinstaller
