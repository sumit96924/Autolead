#!/usr/bin/env python


EMAIL = "thuggame08@gmail.com"
PASSWORD = "n1@gmail.com"
FILE_NAME = "major"
SLEEP_INTERVAL = 1800