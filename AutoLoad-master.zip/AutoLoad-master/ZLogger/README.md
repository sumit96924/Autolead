# ZLogger
Userspace remote keylogger for Linux, works with X, starts on user login, logs key stikes to a file and sends report by email.


