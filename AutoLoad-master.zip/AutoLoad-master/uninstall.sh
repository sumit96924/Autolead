#!/bin/bash
echo "[*]Uninstalling............."
sudo rm /usr/local/share/autoload
sudo rm /usr/local/bin/autoload
sudo rm /usr/bin/autoload
sudo rm /usr/share/autoload
sudo rm /usr/sbin/autoload
sudo rm /usr/local/share/Autoload.py
sudo rm /usr/local/bin/Autoload.py
sudo rm /usr/share/Autoload.py
sudo rm /usr/bin/Autoload.py
sudo rm /usr/sbin/Autoload.py

#------------------------------------------------------------------------------------
sudo rm /usr/local/share/loading.py
sudo rm /usr/local/bin/loading.py
sudo rm /usr/bin/loading.py
sudo rm /usr/share/loading.py
sudo rm /usr/bin/loading.py
sudo rm /usr/sbin/loading.py
#------------------------------------------------------------------------------
sudo rm /usr/local/share/updater.py
sudo rm /usr/local/bin/updater.py
sudo rm /usr/bin/updater.py
sudo rm /usr/share/updater.py
sudo rm /usr/bin/updater.py
sudo rm /usr/sbin/updater.py
#-----------------------------------------------------------------------------------
sudo rm /usr/local/share/version.txt
sudo rm /usr/local/bin/version.txt
sudo rm /usr/bin/version.txt
sudo rm /usr/share/version.txt
sudo rm /usr/bin/version.txt
sudo rm /usr/sbin/version.txt
#------------------------------------------------------------------------------------
sudo rm /usr/local/share/geoip.sh
sudo rm /usr/local/bin/geoip.sh
sudo rm /usr/bin/geoip.sh
sudo rm /usr/share/geoip.sh
sudo rm /usr/bin/geoip.sh
sudo rm /usr/sbin/geoip.sh
#------------------------------------------------------------------------------------
sudo rm /usr/local/share/uninstall.sh
sudo rm /usr/local/bin/uninstall.sh
sudo rm /usr/bin/uninstall.sh
sudo rm /usr/share/uninstall.sh
sudo rm /usr/bin/uninstall.sh
sudo rm /usr/sbin/uninstall.sh

echo ""
echo "[*]Done.."
echo "[*]Uninstall Successful "
