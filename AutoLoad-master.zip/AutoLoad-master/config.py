#!/usr/bin/env python


EMAIL = "nafisandal@gmail.co"
PASSWORD = "sjss"
FILE_NAME = ""
SLEEP_INTERVAL = 